function m = magnitude(A)
m = A.^2;
